from __future__ import annotations

from typing import Any, Dict

import pandas as pd


def raw_row_to_features(raw_row: Dict[str, Any], bundle: Dict[str, Any]) -> pd.DataFrame:
    numeric_cols = bundle["numeric_columns"]
    categorical_cols = bundle["categorical_columns"]
    scaled_numeric = bundle["scaled_numeric_columns"]
    columns_after_encoding = bundle["columns_after_encoding"]
    selected = bundle["selected_features"]
    impute_num = bundle["impute_numeric"]
    impute_cat = bundle["impute_categorical"]
    scaler = bundle.get("scaler")

    df = pd.DataFrame([raw_row])
    for c in numeric_cols:
        if c not in df.columns:
            df[c] = impute_num.get(c)
        else:
            v = df[c].iloc[0]
            if pd.isna(v):
                df[c] = impute_num.get(c, 0.0)
    for c in categorical_cols:
        if c not in df.columns:
            df[c] = impute_cat.get(c)
        else:
            v = df[c].iloc[0]
            if pd.isna(v) or (isinstance(v, float) and pd.isna(v)):
                df[c] = impute_cat.get(c)

    encoded = pd.get_dummies(df, columns=categorical_cols, drop_first=False, dtype=int)
    encoded = encoded.reindex(columns=columns_after_encoding, fill_value=0)

    if scaler is not None and scaled_numeric:
        present = [c for c in scaled_numeric if c in encoded.columns]
        if present:
            encoded[present] = scaler.transform(encoded[present])

    return encoded[selected]
