from __future__ import annotations

import argparse
import json
import logging
import re
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import joblib
import numpy as np
import pandas as pd
from sklearn.preprocessing import MinMaxScaler

logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")
logger = logging.getLogger(__name__)

TARGET_HINTS = ("target", "label", "class", "outcome", "disease", "heart_disease")
ID_HINTS = ("id", "index", "patient", "name", "unnamed")


def _json_serializable(obj: Any) -> Any:
    if isinstance(obj, dict):
        return {k: _json_serializable(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [_json_serializable(v) for v in obj]
    if isinstance(obj, (np.integer, np.int64, np.int32)):
        return int(obj)
    if isinstance(obj, (np.floating, np.float64, np.float32)):
        return float(obj)
    if isinstance(obj, np.ndarray):
        return _json_serializable(obj.tolist())
    if isinstance(obj, (bool, str)) or obj is None:
        return obj
    if hasattr(obj, "item"):
        try:
            return _json_serializable(obj.item())
        except Exception:
            return str(obj)
    return obj


def _normalize_name(name: str) -> str:
    return re.sub(r"[^a-z0-9]+", "_", str(name).strip().lower()).strip("_")


def detect_target_column(df: pd.DataFrame) -> str:
    cols = list(df.columns)
    lowered = {c: _normalize_name(c) for c in cols}

    for c in cols:
        for hint in TARGET_HINTS:
            if hint in lowered[c]:
                return c

    last = cols[-1]
    if df[last].dropna().nunique() <= 10:
        return last

    raise ValueError(
        "Could not infer target column. Name a column with 'target', 'label', or similar, "
        "or ensure the label column is last."
    )


def is_id_column(series: pd.Series, name: str) -> bool:
    n = _normalize_name(name)
    if any(h in n for h in ID_HINTS):
        return True
    if series.dtype == object:
        return False
    if pd.api.types.is_integer_dtype(series) and series.nunique() > 0.95 * len(series):
        return True
    return False


def infer_feature_columns(df: pd.DataFrame, target_col: str) -> List[str]:
    features = []
    for c in df.columns:
        if c == target_col:
            continue
        if is_id_column(df[c], c):
            logger.info("Excluding column (treated as ID): %s", c)
            continue
        features.append(c)
    if not features:
        raise ValueError("No feature columns after excluding target/IDs.")
    return features


def split_numeric_categorical(
    df: pd.DataFrame, feature_cols: List[str], max_categorical_unique: int = 12
) -> Tuple[List[str], List[str]]:
    numeric_cols: List[str] = []
    categorical_cols: List[str] = []

    for c in feature_cols:
        s = df[c]
        if pd.api.types.is_bool_dtype(s):
            categorical_cols.append(c)
            continue
        if pd.api.types.is_numeric_dtype(s):
            nuniq = s.dropna().nunique()
            if nuniq <= max_categorical_unique and nuniq <= len(s) * 0.2:
                categorical_cols.append(c)
            else:
                numeric_cols.append(c)
        else:
            categorical_cols.append(c)

    return numeric_cols, categorical_cols


def handle_missing_values(df: pd.DataFrame, numeric_cols: List[str], categorical_cols: List[str]) -> pd.DataFrame:
    out = df.copy()
    for c in numeric_cols:
        med = out[c].median()
        out[c] = out[c].fillna(med)
    for c in categorical_cols:
        mode = out[c].mode(dropna=True)
        fill = mode.iloc[0] if len(mode) else 0
        out[c] = out[c].fillna(fill)
    return out


def one_hot_encode(df: pd.DataFrame, categorical_cols: List[str]) -> pd.DataFrame:
    if not categorical_cols:
        return df
    return pd.get_dummies(df, columns=categorical_cols, drop_first=False, dtype=int)


def minmax_scale(df: pd.DataFrame, numeric_cols: List[str]) -> Tuple[pd.DataFrame, Dict[str, Any]]:
    out = df.copy()
    present = [c for c in numeric_cols if c in out.columns]
    if not present:
        return out, {}
    scaler = MinMaxScaler()
    out[present] = scaler.fit_transform(out[present])
    meta = {"columns": present, "scaler": scaler}
    return out, meta


def correlation_feature_selection(
    X: pd.DataFrame, y: pd.Series, min_abs_corr: float = 0.02
) -> List[str]:
    aligned = pd.concat([X, y.rename("__target__")], axis=1).dropna()
    if aligned.empty:
        return list(X.columns)

    corrs = aligned.corr(numeric_only=True)["__target__"].drop("__target__", errors="ignore")
    corrs = corrs.reindex(X.columns).fillna(0.0)
    selected = [c for c in X.columns if abs(float(corrs.get(c, 0.0))) >= min_abs_corr]

    if len(selected) < max(3, min(5, len(X.columns) // 4)):
        k = min(max(5, len(X.columns) // 3), len(X.columns))
        top = corrs.abs().sort_values(ascending=False).head(k).index.tolist()
        selected = [c for c in X.columns if c in top]

    logger.info(
        "Feature selection: %d -> %d features (|corr| >= %.3f or top-k fallback)",
        len(X.columns),
        len(selected),
        min_abs_corr,
    )
    return selected


def build_cleaned_frame(
    raw_path: Path,
    output_csv: Path,
    metadata_json: Optional[Path] = None,
    min_abs_corr: float = 0.02,
) -> Tuple[pd.DataFrame, Dict[str, Any], Dict[str, Any]]:
    df = pd.read_csv(raw_path)
    print("Dataset columns:", list(df.columns))

    target_col = detect_target_column(df)
    logger.info("Detected target column: %s", target_col)

    y = df[target_col]
    feature_cols = infer_feature_columns(df, target_col)
    X_raw = df[feature_cols].copy()

    numeric_cols, categorical_cols = split_numeric_categorical(X_raw, feature_cols)
    logger.info("Numeric columns: %s", numeric_cols)
    logger.info("Categorical columns: %s", categorical_cols)

    X_filled = handle_missing_values(X_raw, numeric_cols, categorical_cols)
    X_encoded = one_hot_encode(X_filled, categorical_cols)

    still_numeric = [c for c in numeric_cols if c in X_encoded.columns]
    X_scaled, scale_meta = minmax_scale(X_encoded, still_numeric)

    y_clean = y.copy()
    if y_clean.isna().any():
        drop_idx = y_clean.isna()
        X_scaled = X_scaled.loc[~drop_idx].reset_index(drop=True)
        y_clean = y_clean.loc[~drop_idx].reset_index(drop=True)
        logger.warning("Dropped %d rows with missing target.", int(drop_idx.sum()))

    selected_features = correlation_feature_selection(X_scaled, y_clean, min_abs_corr=min_abs_corr)
    X_final = X_scaled[selected_features]

    cleaned = X_final.copy()
    cleaned[target_col] = y_clean.values

    output_csv.parent.mkdir(parents=True, exist_ok=True)
    cleaned.to_csv(output_csv, index=False)
    logger.info("Saved cleaned dataset to %s", output_csv)

    columns_after_encoding = list(X_scaled.columns)
    impute_numeric = X_raw[numeric_cols].median(numeric_only=True).to_dict() if numeric_cols else {}
    impute_categorical: Dict[str, Any] = {}
    for c in categorical_cols:
        mode = X_raw[c].mode(dropna=True)
        impute_categorical[c] = mode.iloc[0] if len(mode) else 0

    meta: Dict[str, Any] = {
        "target_column": target_col,
        "feature_columns": selected_features,
        "original_feature_columns": feature_cols,
        "numeric_columns": still_numeric,
        "categorical_columns": categorical_cols,
        "n_rows": int(len(cleaned)),
        "n_features": int(len(selected_features)),
        "columns_after_encoding": columns_after_encoding,
        "impute_numeric": impute_numeric,
        "impute_categorical": impute_categorical,
    }
    if scale_meta:
        meta["scaled_numeric_columns"] = scale_meta.get("columns", [])

    if metadata_json:
        metadata_json.parent.mkdir(parents=True, exist_ok=True)
        meta_dump = {k: v for k, v in meta.items() if k not in ("scaler",)}
        meta_dump = _json_serializable(meta_dump)
        with open(metadata_json, "w", encoding="utf-8") as f:
            json.dump(meta_dump, f, indent=2)

    return cleaned, meta, scale_meta


def main(argv: Optional[List[str]] = None) -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--input",
        type=Path,
        default=Path(__file__).resolve().parents[1] / "data" / "raw_data.csv",
    )
    parser.add_argument(
        "--output",
        type=Path,
        default=Path(__file__).resolve().parents[1] / "data" / "cleaned_data.csv",
    )
    parser.add_argument(
        "--metadata",
        type=Path,
        default=Path(__file__).resolve().parents[1] / "data" / "processing_metadata.json",
    )
    parser.add_argument(
        "--bundle",
        type=Path,
        default=Path(__file__).resolve().parents[1] / "ml_model" / "preprocessing_bundle.joblib",
    )
    args = parser.parse_args(argv)

    if not args.input.exists():
        logger.error("Input file not found: %s", args.input)
        return 1

    try:
        _, meta, scale_meta = build_cleaned_frame(args.input, args.output, metadata_json=args.metadata)
        bundle = {
            "target_column": meta["target_column"],
            "numeric_columns": meta["numeric_columns"],
            "categorical_columns": meta["categorical_columns"],
            "scaled_numeric_columns": meta.get("scaled_numeric_columns", []),
            "selected_features": meta["feature_columns"],
            "columns_after_encoding": meta["columns_after_encoding"],
            "impute_numeric": meta["impute_numeric"],
            "impute_categorical": meta["impute_categorical"],
            "scaler": scale_meta.get("scaler") if scale_meta else None,
        }
        args.bundle.parent.mkdir(parents=True, exist_ok=True)
        joblib.dump(bundle, args.bundle)
        logger.info("Saved preprocessing bundle to %s", args.bundle)
    except Exception as exc:
        logger.exception("Processing failed: %s", exc)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
