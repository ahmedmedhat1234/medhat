from __future__ import annotations

from experta import Fact, Field, KnowledgeEngine, P, Rule


class PatientFact(Fact):
    age = Field(int)
    cholesterol = Field(int)
    trestbps = Field(int)
    smoking = Field(int)
    exercise = Field(str)
    bmi = Field(float)


class RiskScore(Fact):
    points = Field(int)
    reason = Field(str)


class RiskLevel(Fact):
    level = Field(str)


class HeartRuleEngine(KnowledgeEngine):
    def __init__(self) -> None:
        super().__init__()
        self.total_score = 0
        super().reset()

    def reset(self) -> None:
        self.total_score = 0
        super().reset()

    @Rule(PatientFact(age=P(lambda a: a >= 65)))
    def rule_age_elderly(self):
        self.declare(RiskScore(points=3, reason="Age 65+"))

    @Rule(PatientFact(age=P(lambda a: 55 <= a < 65)))
    def rule_age_mature(self):
        self.declare(RiskScore(points=2, reason="Age 55-64"))

    @Rule(PatientFact(age=P(lambda a: 45 <= a < 55)))
    def rule_age_mid(self):
        self.declare(RiskScore(points=1, reason="Age 45-54"))

    @Rule(PatientFact(cholesterol=P(lambda c: c >= 240)))
    def rule_chol_high(self):
        self.declare(RiskScore(points=3, reason="Cholesterol >= 240 mg/dL"))

    @Rule(PatientFact(cholesterol=P(lambda c: 200 <= c < 240)))
    def rule_chol_borderline(self):
        self.declare(RiskScore(points=1, reason="Cholesterol 200-239 mg/dL"))

    @Rule(PatientFact(trestbps=P(lambda b: b >= 140)))
    def rule_bp_stage2(self):
        self.declare(RiskScore(points=3, reason="Systolic BP >= 140 mmHg"))

    @Rule(PatientFact(trestbps=P(lambda b: 130 <= b < 140)))
    def rule_bp_stage1(self):
        self.declare(RiskScore(points=2, reason="Systolic BP 130-139 mmHg"))

    @Rule(PatientFact(trestbps=P(lambda b: 120 <= b < 130)))
    def rule_bp_elevated(self):
        self.declare(RiskScore(points=1, reason="Systolic BP 120-129 mmHg"))

    @Rule(PatientFact(smoking=P(lambda s: s == 1)))
    def rule_smoker(self):
        self.declare(RiskScore(points=3, reason="Current smoker"))

    @Rule(PatientFact(exercise=P(lambda e: str(e).lower() == "low")))
    def rule_exercise_low(self):
        self.declare(RiskScore(points=2, reason="Low physical activity"))

    @Rule(PatientFact(exercise=P(lambda e: str(e).lower() == "medium")))
    def rule_exercise_medium(self):
        self.declare(RiskScore(points=1, reason="Moderate physical activity"))

    @Rule(PatientFact(bmi=P(lambda b: b >= 30)))
    def rule_bmi_obese(self):
        self.declare(RiskScore(points=3, reason="BMI >= 30 (obesity)"))

    @Rule(PatientFact(bmi=P(lambda b: 25 <= b < 30)))
    def rule_bmi_overweight(self):
        self.declare(RiskScore(points=2, reason="BMI 25-29.9 (overweight)"))

    @Rule(
        PatientFact(age=P(lambda a: a >= 55)),
        PatientFact(cholesterol=P(lambda c: c >= 240)),
    )
    def rule_age_chol_interaction(self):
        self.declare(RiskScore(points=2, reason="Age 55+ with high cholesterol"))

    @Rule(
        PatientFact(trestbps=P(lambda b: b >= 130)),
        PatientFact(smoking=P(lambda s: s == 1)),
    )
    def rule_bp_smoking_interaction(self):
        self.declare(RiskScore(points=2, reason="Elevated BP with smoking"))

    @Rule(
        PatientFact(bmi=P(lambda b: b >= 25)),
        PatientFact(exercise=P(lambda e: str(e).lower() == "low")),
    )
    def rule_bmi_sedentary(self):
        self.declare(RiskScore(points=1, reason="Overweight/obese with low activity"))
