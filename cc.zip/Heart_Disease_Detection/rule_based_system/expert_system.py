from __future__ import annotations

import argparse
import re
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import pandas as pd

_ROOT = Path(__file__).resolve().parents[1]
if str(_ROOT) not in sys.path:
    sys.path.insert(0, str(_ROOT))

from rule_based_system.rules import HeartRuleEngine, PatientFact, RiskScore


def score_to_level(total: int) -> str:
    if total <= 6:
        return "Low"
    if total <= 12:
        return "Medium"
    return "High"


def run_inference(
    age: int,
    cholesterol: int,
    trestbps: int,
    smoking: int,
    exercise: str,
    bmi: float,
) -> Tuple[str, int, List[str]]:
    engine = HeartRuleEngine()
    engine.declare(
        PatientFact(
            age=int(age),
            cholesterol=int(cholesterol),
            trestbps=int(trestbps),
            smoking=int(smoking),
            exercise=str(exercise).lower().strip(),
            bmi=float(bmi),
        )
    )
    engine.run()

    total = 0
    reasons: List[str] = []
    for fact in engine.facts.values():
        if isinstance(fact, RiskScore):
            pts = int(fact.get("points", 0))
            total += pts
            reasons.append(str(fact.get("reason", "")))

    level = score_to_level(total)
    return level, total, reasons


def _norm(s: str) -> str:
    return re.sub(r"[^a-z0-9]+", "_", str(s).strip().lower()).strip("_")


def find_column(columns: List[str], substrings: Tuple[str, ...]) -> Optional[str]:
    for c in columns:
        n = _norm(c)
        for sub in substrings:
            if sub in n:
                return c
    return None


def row_to_expert_inputs(row: pd.Series, columns: Optional[List[str]] = None) -> Dict[str, Any]:
    cols = columns if columns is not None else list(row.index)
    age_c = find_column(cols, ("age",))
    chol_c = find_column(cols, ("chol", "cholesterol"))
    bp_c = find_column(cols, ("trestbps", "bp", "pressure", "systolic"))
    smoke_c = find_column(cols, ("smok", "tobacco", "cigarette"))
    ex_c = find_column(cols, ("exercise", "activity", "fitness"))
    bmi_c = find_column(cols, ("bmi", "body_mass"))
    thalach_c = find_column(cols, ("thalach", "max_hr", "heartrate"))

    def get_int(name: Optional[str], default: int) -> int:
        if not name or name not in row.index:
            return default
        try:
            return int(round(float(row[name])))
        except (TypeError, ValueError):
            return default

    def get_float(name: Optional[str], default: float) -> float:
        if not name or name not in row.index:
            return default
        try:
            return float(row[name])
        except (TypeError, ValueError):
            return default

    age = get_int(age_c, 50)
    chol = get_int(chol_c, 200)
    bp = get_int(bp_c, 120)
    smoking = 0
    if smoke_c:
        try:
            v = row[smoke_c]
            if isinstance(v, (int, float)):
                smoking = 1 if float(v) >= 0.5 else 0
            else:
                smoking = 1 if str(v).lower() in ("1", "yes", "true", "y") else 0
        except Exception:
            smoking = 0

    exercise = "medium"
    if ex_c:
        try:
            ev = str(row[ex_c]).lower()
            if ev in ("low", "medium", "high"):
                exercise = ev
            elif ev in ("0", "1", "2"):
                exercise = ["low", "medium", "high"][int(float(ev)) % 3]
        except Exception:
            exercise = "medium"
    elif thalach_c:
        th = get_int(thalach_c, 150)
        if th >= 155:
            exercise = "high"
        elif th <= 120:
            exercise = "low"
        else:
            exercise = "medium"

    bmi = get_float(bmi_c, 25.0)

    return {
        "age": age,
        "cholesterol": chol,
        "trestbps": bp,
        "smoking": smoking,
        "exercise": exercise,
        "bmi": bmi,
    }


def expert_level_to_binary(level: str, medium_positive: bool = True) -> int:
    if level == "High":
        return 1
    if level == "Medium":
        return 1 if medium_positive else 0
    return 0


def prompt_terminal() -> Dict[str, Any]:
    print("Heart Disease Risk — Expert System (Experta)")
    print("Enter patient data (invalid values will be rejected):\n")

    def ask_int(prompt: str, low: int = 0, high: int = 130) -> int:
        while True:
            try:
                v = int(input(prompt).strip())
                if low <= v <= high:
                    return v
                print(f"Please enter an integer between {low} and {high}.")
            except ValueError:
                print("Invalid integer. Try again.")

    def ask_float(prompt: str, low: float = 10.0, high: float = 60.0) -> float:
        while True:
            try:
                v = float(input(prompt).strip())
                if low <= v <= high:
                    return v
                print(f"Please enter a number between {low} and {high}.")
            except ValueError:
                print("Invalid number. Try again.")

    age = ask_int("Age (years): ", 18, 110)
    chol = ask_int("Total cholesterol (mg/dL): ", 100, 600)
    bp = ask_int("Resting systolic blood pressure (mmHg): ", 80, 250)
    smoke_in = input("Smoker? (0=no, 1=yes): ").strip()
    smoking = 1 if smoke_in in ("1", "yes", "y", "true") else 0
    ex = input("Exercise level (low/medium/high): ").strip().lower()
    if ex not in ("low", "medium", "high"):
        ex = "medium"
    bmi = ask_float("BMI: ", 15.0, 55.0)

    return {
        "age": age,
        "cholesterol": chol,
        "trestbps": bp,
        "smoking": smoking,
        "exercise": ex,
        "bmi": bmi,
    }


def main(argv: Optional[List[str]] = None) -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--no-prompt", action="store_true")
    args = parser.parse_args(argv)

    try:
        if args.no_prompt:
            data = {"age": 55, "cholesterol": 240, "trestbps": 135, "smoking": 0, "exercise": "low", "bmi": 28.0}
        else:
            data = prompt_terminal()
        level, total, reasons = run_inference(
            data["age"],
            data["cholesterol"],
            data["trestbps"],
            data["smoking"],
            data["exercise"],
            data["bmi"],
        )
        print("\n--- Expert System Result ---")
        print(f"Risk level: {level}")
        print(f"Rule score: {total}")
        print("Triggered rules:")
        for r in reasons:
            print(f"  - {r}")
    except KeyboardInterrupt:
        print("\nAborted.")
        return 130
    except Exception as exc:
        print(f"Error: {exc}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
