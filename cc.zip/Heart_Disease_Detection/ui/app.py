from __future__ import annotations

import json
import sys
from pathlib import Path

import pandas as pd
import streamlit as st

_ROOT = Path(__file__).resolve().parents[1]
if str(_ROOT) not in sys.path:
    sys.path.insert(0, str(_ROOT))

from ml_model.predict import load_artifacts, predict_raw
from rule_based_system.expert_system import run_inference, row_to_expert_inputs


def main() -> None:
    st.set_page_config(page_title="Heart Disease Detection", layout="wide")
    st.title("Heart Disease Risk Assessment")
    st.caption("Expert system (Experta) and Decision Tree classifier")

    meta_path = _ROOT / "data" / "processing_metadata.json"
    raw_path = _ROOT / "data" / "raw_data.csv"
    model_path = _ROOT / "ml_model" / "decision_tree_model.joblib"
    bundle_path = _ROOT / "ml_model" / "preprocessing_bundle.joblib"

    if not all(p.exists() for p in (meta_path, raw_path, model_path, bundle_path)):
        st.error(
            "Missing artifacts. Run from project root:\n"
            "`python utils/data_processing.py` then `python ml_model/train_model.py`"
        )
        return

    with open(meta_path, encoding="utf-8") as f:
        meta = json.load(f)
    target_col = meta["target_column"]
    feature_cols = [c for c in meta["original_feature_columns"] if c != target_col]

    artifact, bundle, _ = load_artifacts(model_path, bundle_path, meta_path)
    sample = pd.read_csv(raw_path, nrows=1)
    defaults = sample.iloc[0].to_dict()

    st.subheader("Patient features")
    cols = st.columns(min(4, max(1, len(feature_cols))))
    values: dict = {}
    for i, col in enumerate(feature_cols):
        c = cols[i % len(cols)]
        v = defaults.get(col, 0)
        try:
            fv = float(v)
        except (TypeError, ValueError):
            fv = 0.0
        if fv == int(fv):
            values[col] = int(c.number_input(col, value=int(fv), step=1, key=f"f_{col}"))
        else:
            values[col] = float(c.number_input(col, value=float(fv), format="%.4f", key=f"f_{col}"))

    if st.button("Predict", type="primary"):
        series = pd.Series(values)
        exp_inputs = row_to_expert_inputs(series)
        level, score, reasons = run_inference(
            exp_inputs["age"],
            exp_inputs["cholesterol"],
            exp_inputs["trestbps"],
            exp_inputs["smoking"],
            exp_inputs["exercise"],
            exp_inputs["bmi"],
        )
        try:
            ml_pred = predict_raw(values, artifact, bundle)
        except Exception as e:
            st.error(str(e))
            ml_pred = None

        c1, c2 = st.columns(2)
        with c1:
            st.markdown("### Expert system")
            st.metric("Risk level", level)
            st.metric("Rule score", score)
            for r in reasons:
                st.markdown(f"- {r}")
        with c2:
            st.markdown("### Decision Tree")
            if ml_pred is not None:
                st.metric("Predicted class", ml_pred)
                st.caption("0 = no disease, 1 = disease (training label encoding)")

        st.subheader("Comparison")
        if ml_pred is not None:
            agree = (level == "High" and ml_pred == 1) or (level != "High" and ml_pred == 0)
            st.write("High-level agreement (heuristic):", "Yes" if agree else "No")
            chart = pd.DataFrame(
                {
                    "Model": ["Expert (score)", "ML (0/1)"],
                    "Value": [float(score), float(ml_pred)],
                }
            )
            st.bar_chart(chart.set_index("Model"))


if __name__ == "__main__":
    main()
