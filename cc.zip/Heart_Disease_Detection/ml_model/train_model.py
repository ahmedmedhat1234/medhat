from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any, Dict, List, Tuple

import joblib
import numpy as np
import pandas as pd
from sklearn.metrics import accuracy_score, f1_score, precision_score, recall_score
from sklearn.model_selection import GridSearchCV, train_test_split
from sklearn.tree import DecisionTreeClassifier

_ROOT = Path(__file__).resolve().parents[1]
if str(_ROOT) not in sys.path:
    sys.path.insert(0, str(_ROOT))

from rule_based_system.expert_system import (
    expert_level_to_binary,
    row_to_expert_inputs,
    run_inference,
)


def load_paths(
    cleaned_csv: Path,
    raw_csv: Path,
    metadata_json: Path,
) -> Tuple[pd.DataFrame, pd.DataFrame, Dict[str, Any]]:
    cleaned = pd.read_csv(cleaned_csv)
    raw = pd.read_csv(raw_csv)
    with open(metadata_json, encoding="utf-8") as f:
        meta = json.load(f)
    if len(cleaned) != len(raw):
        raise ValueError("cleaned_data and raw_data must have the same number of rows (same pipeline).")
    return cleaned, raw, meta


def evaluate_expert_on_rows(raw_test: pd.DataFrame, y_test: np.ndarray, medium_positive: bool = True) -> float:
    preds: List[int] = []
    for _, row in raw_test.iterrows():
        inp = row_to_expert_inputs(row)
        level, _, _ = run_inference(
            inp["age"],
            inp["cholesterol"],
            inp["trestbps"],
            inp["smoking"],
            inp["exercise"],
            inp["bmi"],
        )
        preds.append(expert_level_to_binary(level, medium_positive=medium_positive))
    return float(accuracy_score(y_test, np.array(preds)))


def main(argv: List[str] | None = None) -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--cleaned",
        type=Path,
        default=_ROOT / "data" / "cleaned_data.csv",
    )
    parser.add_argument(
        "--raw",
        type=Path,
        default=_ROOT / "data" / "raw_data.csv",
    )
    parser.add_argument(
        "--metadata",
        type=Path,
        default=_ROOT / "data" / "processing_metadata.json",
    )
    parser.add_argument(
        "--model-out",
        type=Path,
        default=_ROOT / "ml_model" / "decision_tree_model.joblib",
    )
    parser.add_argument(
        "--metrics-out",
        type=Path,
        default=_ROOT / "ml_model" / "training_metrics.json",
    )
    parser.add_argument("--random-state", type=int, default=42)
    args = parser.parse_args(argv)

    if not args.cleaned.exists() or not args.raw.exists():
        print("Run utils/data_processing.py first to create cleaned_data.csv and raw_data.csv.", file=sys.stderr)
        return 1

    cleaned, raw, meta = load_paths(args.cleaned, args.raw, args.metadata)
    target_col = meta["target_column"]
    feature_cols = [c for c in cleaned.columns if c != target_col]

    X = cleaned[feature_cols]
    y = cleaned[target_col].astype(int)

    X_train, X_test, y_train, y_test, idx_train, idx_test = train_test_split(
        X,
        y,
        np.arange(len(cleaned)),
        test_size=0.2,
        random_state=args.random_state,
        stratify=y,
    )

    param_grid = {
        "max_depth": [3, 5, 8, 12, None],
        "min_samples_split": [2, 5, 10, 20],
    }
    base = DecisionTreeClassifier(random_state=args.random_state, class_weight="balanced")
    grid = GridSearchCV(
        base,
        param_grid,
        scoring="f1",
        cv=5,
        n_jobs=-1,
    )
    grid.fit(X_train, y_train)
    model = grid.best_estimator_
    y_pred = model.predict(X_test)

    metrics = {
        "best_params": grid.best_params_,
        "accuracy": float(accuracy_score(y_test, y_pred)),
        "precision": float(precision_score(y_test, y_pred, zero_division=0)),
        "recall": float(recall_score(y_test, y_pred, zero_division=0)),
        "f1": float(f1_score(y_test, y_pred, zero_division=0)),
    }

    raw_test = raw.iloc[idx_test].reset_index(drop=True)
    y_test_arr = y_test.values
    try:
        expert_acc = evaluate_expert_on_rows(raw_test, y_test_arr, medium_positive=True)
    except Exception as exc:
        expert_acc = float("nan")
        print(f"Warning: expert evaluation failed: {exc}", file=sys.stderr)

    metrics["expert_accuracy_proxy"] = expert_acc
    metrics["note"] = (
        "Expert accuracy uses the same test rows with heuristic mapping from raw columns "
        "to age/chol/BP/smoking/exercise/BMI; Medium+High counts as positive when medium_positive=True."
    )

    args.model_out.parent.mkdir(parents=True, exist_ok=True)
    artifact = {
        "model": model,
        "feature_names": feature_cols,
        "target_column": target_col,
        "best_params": grid.best_params_,
        "metrics": metrics,
    }
    joblib.dump(artifact, args.model_out)
    with open(args.metrics_out, "w", encoding="utf-8") as f:
        json.dump(metrics, f, indent=2)

    print("Best params:", grid.best_params_)
    print("Test metrics:", {k: v for k, v in metrics.items() if k in ("accuracy", "precision", "recall", "f1")})
    print("Expert system proxy accuracy (test set):", expert_acc)
    print("Saved model to", args.model_out)
    return 0


if __name__ == "__main__":
    sys.exit(main())
