from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional

import joblib
import pandas as pd

_ROOT = Path(__file__).resolve().parents[1]
if str(_ROOT) not in sys.path:
    sys.path.insert(0, str(_ROOT))

from utils.raw_transform import raw_row_to_features


def load_artifacts(
    model_path: Path,
    bundle_path: Path,
    metadata_path: Path,
) -> tuple:
    artifact = joblib.load(model_path)
    bundle = joblib.load(bundle_path)
    with open(metadata_path, encoding="utf-8") as f:
        meta = json.load(f)
    return artifact, bundle, meta


def predict_raw(
    raw_row: Dict[str, Any],
    artifact: Dict[str, Any],
    bundle: Dict[str, Any],
) -> int:
    X = raw_row_to_features(raw_row, bundle)
    model = artifact["model"]
    pred = model.predict(X)[0]
    return int(pred)


def main(argv: Optional[List[str]] = None) -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--model",
        type=Path,
        default=_ROOT / "ml_model" / "decision_tree_model.joblib",
    )
    parser.add_argument(
        "--bundle",
        type=Path,
        default=_ROOT / "ml_model" / "preprocessing_bundle.joblib",
    )
    parser.add_argument(
        "--metadata",
        type=Path,
        default=_ROOT / "data" / "processing_metadata.json",
    )
    parser.add_argument(
        "--sample-json",
        type=Path,
    )
    args = parser.parse_args(argv)

    if not args.model.exists() or not args.bundle.exists():
        print("Train the model and run data processing first.", file=sys.stderr)
        return 1

    artifact, bundle, meta = load_artifacts(args.model, args.bundle, args.metadata)
    target_col = meta["target_column"]
    raw_cols = [c for c in meta["original_feature_columns"] if c != target_col]

    if args.sample_json:
        with open(args.sample_json, encoding="utf-8") as f:
            raw_row = json.load(f)
    else:
        raw_path = _ROOT / "data" / "raw_data.csv"
        if not raw_path.exists():
            print("Provide --sample-json or place data/raw_data.csv", file=sys.stderr)
            return 1
        df0 = pd.read_csv(raw_path, nrows=1)
        raw_row = df0.iloc[0].drop(labels=[target_col], errors="ignore").to_dict()

    filtered = {k: raw_row[k] for k in raw_cols if k in raw_row}

    try:
        pred = predict_raw(filtered, artifact, bundle)
        print("Predicted class (0/1):", pred)
    except Exception as exc:
        print(f"Prediction failed: {exc}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
